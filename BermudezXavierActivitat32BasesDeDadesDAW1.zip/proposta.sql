mysql> -- Per conseguir fer-ho, s'hauria de modificar algun prestec perque aquest hagi tardat en ser entregat mes de 3 dies o introduir un nou
mysql> INSERT INTO PRESTECS VALUES (1,19,3,'2020-10-24','2020-10-30');
Query OK, 1 row affected (0.00 sec)

mysql> INSERT INTO PRESTECS VALUES (1,19,3,'2020-11-24','2020-11-29');
Query OK, 1 row affected (0.01 sec)

mysql> tee Solucio.sql;
