mysql> -- Ja he introduit dos registres que superin 3 dies de prestec com podem veure en la proxima taula
mysql> select *,(data_retorn-data_prestec) dies from PRESTECS where (data_retorn-data_prestec) > 3;
+---------+---------+--------------+--------------+-------------+------+
| id_soci | id_peli | num_exemplar | data_prestec | data_retorn | dies |
+---------+---------+--------------+--------------+-------------+------+
| 1       |      19 |            3 | 2020-10-24   | 2020-10-30  |    6 |
| 1       |      19 |            3 | 2020-11-24   | 2020-11-29  |    5 |
+---------+---------+--------------+--------------+-------------+------+
2 rows in set (0.00 sec)

mysql> select PELLICULES.titol_peli,PRESTECS.num_exemplar,SOCIS.nom_soci,PRESTECS.data_prestec,PRESTECS.data_retorn,(PRESTECS.data_retorn - PRESTECS.data_prestec) dies FROM PELLICULES,PRESTECS,SOCIS WHERE PELLICULES.id_peli = PRESTECS.id_peli AND PRESTECS.id_soci = SOCIS.id_soci AND (PRESTECS.data_retorn - PRESTECS.data_prestec)> 3;
+------------+--------------+----------+--------------+-------------+------+
| titol_peli | num_exemplar | nom_soci | data_prestec | data_retorn | dies |
+------------+--------------+----------+--------------+-------------+------+
| MABOROSHI  |            3 | BOB      | 2020-10-24   | 2020-10-30  |    6 |
| MABOROSHI  |            3 | BOB      | 2020-11-24   | 2020-11-29  |    5 |
+------------+--------------+----------+--------------+-------------+------+
2 rows in set (0.00 sec)
